# England Property Deals

A free, no-signup tool that turns HM Land Registry's official **Price Paid
Data** into a shortlist of refurb, Buy-to-Let and HMO opportunities across
England. No scraping, no API keys, no paid services required.

## How the data works

- **Sold prices & addresses** — real, official transactions from
  [HM Land Registry Price Paid Data](https://www.gov.uk/government/statistical-data-sets/price-paid-data-downloads),
  free under the Open Government Licence, no signup, no key. Updated by HM
  Land Registry every month.
- **Rent/yield estimates** — there is no free, legal, live rent API, so
  `scripts/build-deals.js` uses a small hard-coded reference table you
  should refresh periodically from
  [ONS Private Rental Market Statistics](https://www.ons.gov.uk/economy/inflationandpriceindices/bulletins/privaterentandhousepricesuk)
  (also free). This is clearly labelled as indicative in the UI.

## Run it locally (takes ~1 minute)

```bash
node scripts/build-deals.js
```

This downloads the current year's Price Paid Data CSV (~9MB, no key needed)
and writes `data/deals.json`. Open `index.html` in a browser (or serve the
folder) to see it.

## Deploy it for free, fully automated

1. Push this folder to a new **public** GitHub repository.
2. In the repo settings, enable **GitHub Pages** (serve from the
   repository root / `main` branch).
3. The included workflow, `.github/workflows/update-deals.yml`, runs on
   GitHub's free public-repo runners on the 25th of every month (after HM
   Land Registry's usual release date) and commits a refreshed
   `data/deals.json` automatically. You can also trigger it manually from
   the Actions tab any time.

That's the whole stack: **GitHub Pages (free hosting) + GitHub Actions
(free scheduled job) + HM Land Registry (free official data)** — zero
ongoing cost, no signup for your visitors, no scraping.

## Adding the £20/month subscription (no signup, just payment)

Visitors get a genuine free demo — one real deal per strategy — then hit a
blurred paywall for the rest. No account, no password: just Stripe
Checkout, and access is checked against your *real* Stripe subscription
status every time, so a cancellation actually revokes access.

**1. Stripe (free to open, ~1.5%+20p per UK transaction — unavoidable,
that's how card processing works anywhere):**
- Create a Product ("England Property Deals") with a £20/month recurring price.
- Create a **Payment Link** for it.
- Under the Payment Link's settings, set the confirmation page to
  redirect to your site with `?session_id={CHECKOUT_SESSION_ID}` appended,
  e.g. `https://you.github.io/property-deals/?session_id={CHECKOUT_SESSION_ID}`.
- Copy the Payment Link URL into `PAYMENT_LINK_URL` near the top of the
  `<script>` block in `index.html`.
- Grab your **secret key** (Developers → API keys) — you'll need it in step 2.

**2. Cloudflare Worker (free tier, 100,000 requests/day):**
```bash
cd cloudflare
npm install -g wrangler   # one-off, free
wrangler login
wrangler secret put STRIPE_SECRET_KEY   # paste your Stripe secret key when prompted
```
Edit `wrangler.toml`: set `DEALS_JSON_URL` to your raw GitHub URL for
`data/deals.json`, and `ALLOWED_ORIGIN` to your site's URL. Then:
```bash
wrangler deploy
```
Copy the `*.workers.dev` URL it prints into `WORKER_BASE_URL` near the top
of the `<script>` block in `index.html`.

**How it works end to end:** visitor pays via the Payment Link → Stripe
redirects back with a session ID → the Worker confirms payment and hands
back the subscription ID → the browser stores just that ID locally →
every time the page loads, the Worker re-checks with Stripe that the
subscription is still active before releasing the real dataset. Nothing
is stored on your end beyond what Stripe already stores.

**Honest limitation:** this is a lightweight, no-database setup suitable
for a solo/early-stage product. The subscription ID acts as a bearer
credential — hard to guess, but if someone deliberately shared their ID
they could share access. For a stricter setup later, add signed,
short-lived tokens (HMAC) issued by the Worker instead of trusting the
raw subscription ID — happy to add that if this takes off.

## Customising

- **Add/remove areas or towns:** edit the `AREAS` object in
  `scripts/build-deals.js` — it maps your area keys to the `Town/City`
  values used in Price Paid Data.
- **Update rent estimates:** edit `RENT_TABLE` in the same file.
- **Change the refurb/HMO thresholds:** see the `buildAreaDeals` function —
  refurb candidates are houses priced under 75% of the local median, HMO
  candidates are houses priced over 110% of it. Adjust to taste.
- **Want live rent data / more listing detail?** A paid option like
  [PropertyData.co.uk](https://propertydata.co.uk) has a UK-specific API
  with yields and Article 4 Direction data — swap it in where `RENT_TABLE`
  is used if you decide it's worth the subscription later.
