/**
 * worker.js — Cloudflare Worker (free tier: 100,000 requests/day, £0)
 * ----------------------------------------------------------------------
 * Two jobs, both talking directly to Stripe's real API — no database,
 * no accounts, nothing for the visitor to sign up for on your site:
 *
 *   GET /api/resolve?session_id=cs_xxx
 *     Called once, right after Stripe redirects a paying visitor back
 *     to your site. Confirms the Checkout Session actually paid, and
 *     returns the underlying subscription ID. The site stores that ID
 *     in the visitor's own browser (localStorage) — nothing stored here.
 *
 *   GET /api/deals?sub=sub_xxx
 *     Called whenever the site wants the full dataset. Asks Stripe
 *     "is this subscription still active right now?" and only returns
 *     the real deals.json if it is. Cancel the subscription in Stripe
 *     and access stops on the very next request — no separate database
 *     to keep in sync.
 *
 * Required secrets (set with `wrangler secret put NAME`, both free):
 *   STRIPE_SECRET_KEY   — your Stripe secret key (sk_live_... or sk_test_...)
 *
 * Required variable (set in wrangler.toml or the dashboard):
 *   DEALS_JSON_URL       — raw URL to the deals.json your GitHub Action
 *                           publishes, e.g.
 *                           https://raw.githubusercontent.com/<you>/<repo>/main/data/deals.json
 *   ALLOWED_ORIGIN        — your site's URL, for CORS, e.g. https://you.github.io
 * ----------------------------------------------------------------------
 */

function corsHeaders(env) {
  return {
    'Access-Control-Allow-Origin': env.ALLOWED_ORIGIN || '*',
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  };
}

async function stripeGet(path, env) {
  const res = await fetch(`https://api.stripe.com/v1/${path}`, {
    headers: { Authorization: `Bearer ${env.STRIPE_SECRET_KEY}` },
  });
  const json = await res.json();
  if (!res.ok) throw new Error(json.error?.message || `Stripe error ${res.status}`);
  return json;
}

async function handleResolve(url, env) {
  const sessionId = url.searchParams.get('session_id');
  if (!sessionId) return jsonResponse({ error: 'Missing session_id' }, 400, env);

  const session = await stripeGet(`checkout/sessions/${sessionId}`, env);
  if (session.payment_status !== 'paid' && session.status !== 'complete') {
    return jsonResponse({ error: 'Payment not completed' }, 402, env);
  }
  if (!session.subscription) {
    return jsonResponse({ error: 'No subscription on this session' }, 400, env);
  }
  return jsonResponse({ subscriptionId: session.subscription }, 200, env);
}

async function handleDeals(url, env) {
  const subId = url.searchParams.get('sub');
  if (!subId) return jsonResponse({ error: 'Missing sub' }, 401, env);

  let sub;
  try {
    sub = await stripeGet(`subscriptions/${subId}`, env);
  } catch (e) {
    return jsonResponse({ error: 'Invalid subscription' }, 401, env);
  }
  if (!['active', 'trialing'].includes(sub.status)) {
    return jsonResponse({ error: 'Subscription is not active', status: sub.status }, 402, env);
  }

  const dealsRes = await fetch(env.DEALS_JSON_URL, { cf: { cacheTtl: 300 } });
  if (!dealsRes.ok) return jsonResponse({ error: 'Could not load deals data' }, 502, env);
  const deals = await dealsRes.json();
  return jsonResponse(deals, 200, env);
}

function jsonResponse(obj, status, env) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { 'Content-Type': 'application/json', ...corsHeaders(env) },
  });
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (request.method === 'OPTIONS') {
      return new Response(null, { headers: corsHeaders(env) });
    }

    try {
      if (url.pathname === '/api/resolve') return await handleResolve(url, env);
      if (url.pathname === '/api/deals') return await handleDeals(url, env);
      return jsonResponse({ error: 'Not found' }, 404, env);
    } catch (e) {
      return jsonResponse({ error: e.message }, 500, env);
    }
  },
};
